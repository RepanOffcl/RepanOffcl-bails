module.exports = {
  BOT_TOKEN: "8158026911:AAF6yi9LhnYvYH2J3slwcFXgzTPsx5RFpWQ",
  OWNER_ID: ["7911354291"],
};